

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-people me-2"></i>Personas</h3>
    <a href="<?php echo e(route('personas.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nueva Persona
    </a>
</div>

<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('personas.index')); ?>" class="row g-2">
            <div class="col-md-4">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar por nombre o documento..."
                       value="<?php echo e(request('buscar')); ?>">
            </div>
            <div class="col-md-3">
                <select name="tipo" class="form-select">
                    <option value="">Todos los tipos</option>
                    <option value="CLIENTE" <?php echo e(request('tipo') == 'CLIENTE' ? 'selected' : ''); ?>>Cliente</option>
                    <option value="PROVEEDOR" <?php echo e(request('tipo') == 'PROVEEDOR' ? 'selected' : ''); ?>>Proveedor</option>
                    <option value="EMPLEADO" <?php echo e(request('tipo') == 'EMPLEADO' ? 'selected' : ''); ?>>Empleado</option>
                    <option value="AMBOS" <?php echo e(request('tipo') == 'AMBOS' ? 'selected' : ''); ?>>Cliente y Proveedor</option>
                </select>
            </div>
            <div class="col-md-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if(request('buscar') || request('tipo')): ?>
                <a href="<?php echo e(route('personas.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Nombre / Razón Social</th>
                    <th>Tipo</th>
                    <th>Documento</th>
                    <th>Teléfono</th>
                    <th>Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($persona->razon_social_nombre); ?></td>
                    <td>
                        <?php
                            $badgeColor = match($persona->tipo_persona) {
                                'CLIENTE' => 'info',
                                'PROVEEDOR' => 'warning',
                                'EMPLEADO' => 'secondary',
                                'AMBOS' => 'primary',
                                default => 'secondary',
                            };
                        ?>
                        <span class="badge bg-<?php echo e($badgeColor); ?>"><?php echo e($persona->tipo_persona); ?></span>
                    </td>
                    <td><?php echo e($persona->tipo_documento); ?>: <?php echo e($persona->numero_documento); ?></td>
                    <td><?php echo e($persona->telefono); ?></td>
                    <td>
                        <?php if($persona->estado): ?>
                            <span class="badge bg-success">Activa</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Inactiva</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('personas.edit', $persona)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form action="<?php echo e(route('personas.destroy', $persona)); ?>" method="POST" class="d-inline"
                              onsubmit="return confirm('¿Eliminar esta persona?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">No hay personas cargadas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($personas->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/personas/index.blade.php ENDPATH**/ ?>