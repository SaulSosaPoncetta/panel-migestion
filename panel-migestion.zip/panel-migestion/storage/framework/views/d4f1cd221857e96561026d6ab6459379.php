

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-building me-2"></i><?php echo e($empresa->razon_social); ?></h3>
    <a href="<?php echo e(route('superadmin.empresas.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">CUIT</div>
                <div class="fw-semibold"><?php echo e($empresa->identificacion_fiscal); ?></div>
                <div class="text-muted small mt-2">Fecha de Alta</div>
                <div><?php echo e(\Illuminate\Support\Carbon::parse($empresa->creado_en)->format('d/m/Y H:i')); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Estado</div>
                <?php if($empresa->estado): ?>
                    <span class="badge bg-success fs-6">Activa</span>
                <?php else: ?>
                    <span class="badge bg-danger fs-6">Suspendida</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <?php if($empresa->estado): ?>
                <form action="<?php echo e(route('superadmin.empresas.suspender', $empresa)); ?>" method="POST"
                      onsubmit="return confirm('¿Suspender esta empresa?');">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger w-100">
                        <i class="bi bi-pause-circle me-1"></i> Suspender Empresa
                    </button>
                </form>
                <?php else: ?>
                <form action="<?php echo e(route('superadmin.empresas.activar', $empresa)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-success w-100">
                        <i class="bi bi-play-circle me-1"></i> Reactivar Empresa
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-people me-1"></i> Usuarios de esta Empresa
    </div>
    <div class="card-body p-0">
        <table class="table mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Roles</th>
                    <th>Alta</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td>
                        <?php $__currentLoopData = $usuario->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary"><?php echo e($rol); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e($usuario->created_at->format('d/m/Y')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">No hay usuarios en esta empresa.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercialsaas\resources\views/superadmin/empresas/show.blade.php ENDPATH**/ ?>