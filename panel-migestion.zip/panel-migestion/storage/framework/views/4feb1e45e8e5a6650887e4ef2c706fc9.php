

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-cash-coin me-2"></i>Listas de Precios</h3>
    <a href="<?php echo e(route('listas-precios.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nueva Lista
    </a>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Nombre</th>
                    <th>% Ganancia Base</th>
                    <th>Predeterminada</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $listasPrecios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($lista->nombre); ?></td>
                    <td><?php echo e($lista->porcentaje_ganancia_base !== null ? number_format($lista->porcentaje_ganancia_base, 2).'%' : '—'); ?></td>
                    <td>
                        <?php if($lista->es_predeterminada): ?>
                            <span class="badge bg-primary">Sí</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">No</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('listas-precios.precios', $lista)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-currency-dollar"></i> Precios
                        </a>
                        <a href="<?php echo e(route('listas-precios.edit', $lista)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form action="<?php echo e(route('listas-precios.destroy', $lista)); ?>" method="POST" class="d-inline"
                              onsubmit="return confirm('¿Eliminar esta lista de precios?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">No hay listas de precios cargadas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($listasPrecios->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/listas-precios/index.blade.php ENDPATH**/ ?>