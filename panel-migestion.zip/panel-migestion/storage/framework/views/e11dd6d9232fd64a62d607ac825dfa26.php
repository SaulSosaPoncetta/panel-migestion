

<?php $__env->startSection('content'); ?>
<h3 class="mb-4"><i class="bi bi-people me-2"></i>Nueva Persona</h3>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="<?php echo e(route('personas.store')); ?>" method="POST">
            <?php echo $__env->make('personas._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/personas/create.blade.php ENDPATH**/ ?>