

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-currency-dollar me-2"></i>Precios — <?php echo e($listaPrecio->nombre); ?></h3>
    <a href="<?php echo e(route('listas-precios.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="<?php echo e(route('listas-precios.guardarPrecios', $listaPrecio)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>SKU</th>
                            <th>Producto</th>
                            <th class="text-end" style="width: 200px;">Precio de Venta</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($producto->sku); ?></td>
                            <td><?php echo e($producto->nombre); ?></td>
                            <td>
                                <input type="number" step="0.01" min="0"
                                       name="precios[<?php echo e($producto->id_producto); ?>]"
                                       class="form-control text-end"
                                       value="<?php echo e(old('precios.'.$producto->id_producto, $preciosActuales[$producto->id_producto] ?? '')); ?>">
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3" class="text-center text-muted py-4">No hay productos activos cargados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($productos->isNotEmpty()): ?>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Guardar Precios</button>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/listas-precios/precios.blade.php ENDPATH**/ ?>