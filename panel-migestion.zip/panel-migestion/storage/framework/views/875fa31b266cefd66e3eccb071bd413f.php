

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-buildings me-2"></i>Panel Superadmin — Empresas</h3>
</div>

<div class="alert alert-dark">
    <i class="bi bi-shield-lock me-1"></i>
    Estás viendo todas las empresas registradas en el sistema, fuera del filtrado normal por empresa.
</div>

<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('superadmin.empresas.index')); ?>" class="d-flex gap-2">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por razón social o CUIT..."
                   value="<?php echo e(request('buscar')); ?>">
            <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
            <?php if(request('buscar')): ?>
            <a href="<?php echo e(route('superadmin.empresas.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Razón Social</th>
                    <th>CUIT</th>
                    <th>Alta</th>
                    <th class="text-end">Sucursales</th>
                    <th class="text-end">Usuarios</th>
                    <th>Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($empresa->razon_social); ?></td>
                    <td><?php echo e($empresa->identificacion_fiscal); ?></td>
                    <td><?php echo e(\Illuminate\Support\Carbon::parse($empresa->creado_en)->format('d/m/Y')); ?></td>
                    <td class="text-end"><?php echo e($empresa->sucursales_count); ?></td>
                    <td class="text-end"><?php echo e($usuariosPorEmpresa[$empresa->id_empresa] ?? 0); ?></td>
                    <td>
                        <?php if($empresa->estado): ?>
                            <span class="badge bg-success">Activa</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Suspendida</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('superadmin.empresas.show', $empresa)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-eye"></i>
                        </a>
                        <?php if($empresa->estado): ?>
                        <form action="<?php echo e(route('superadmin.empresas.suspender', $empresa)); ?>" method="POST" class="d-inline"
                              onsubmit="return confirm('¿Suspender esta empresa? Sus usuarios no podrán loguearse.');">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-pause-circle"></i> Suspender
                            </button>
                        </form>
                        <?php else: ?>
                        <form action="<?php echo e(route('superadmin.empresas.activar', $empresa)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-success">
                                <i class="bi bi-play-circle"></i> Reactivar
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No hay empresas registradas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($empresas->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercialsaas\resources\views/superadmin/empresas/index.blade.php ENDPATH**/ ?>