

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0"><i class="bi bi-boxes me-2"></i>Stock</h3>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('stock.historial')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-clock-history me-1"></i> Historial
            </a>
            <a href="<?php echo e(route('stock.ajustar')); ?>" class="btn btn-primary">
                <i class="bi bi-sliders me-1"></i> Ajustar Stock
            </a>
        </div>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body py-2">
            <form method="GET" action="<?php echo e(route('stock.index')); ?>" class="row g-2">
                <div class="col-md-4">
                    <input type="text" name="buscar" class="form-control" placeholder="Buscar por nombre o SKU..."
                        value="<?php echo e(request('buscar')); ?>">
                </div>
                <div class="col-md-4">
                    <select name="id_almacen" class="form-select">
                        <option value="">Todos los almacenes</option>
                        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($alm->id_almacen); ?>"
                                <?php echo e(request('id_almacen') == $alm->id_almacen ? 'selected' : ''); ?>>
                                <?php echo e($alm->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-auto">
                    <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                    <?php if(request('buscar') || request('id_almacen')): ?>
                        <a href="<?php echo e(route('stock.index')); ?>" class="btn btn-outline-secondary"><i
                                class="bi bi-x-lg"></i></a>
                    <?php endif; ?>
                </div>
                <div class="col-md-auto ms-auto">
                    <a href="<?php echo e(route('stock.exportar', request()->query())); ?>" class="btn btn-outline-success">
                        <i class="bi bi-file-earmark-excel me-1"></i> Exportar a Excel
                    </a>
                </div>
            </form>
        </div>
    </div>
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>SKU</th>
                        <th>Producto</th>
                        <th>Almacén</th>
                        <th class="text-end">Cantidad</th>
                        <th class="text-end">Stock Mínimo</th>
                        <th>Alerta</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->producto->sku ?? '—'); ?></td>
                            <td><?php echo e($item->producto->nombre ?? '—'); ?></td>
                            <td><?php echo e($item->almacen->nombre ?? '—'); ?></td>
                            <td class="text-end"><?php echo e(rtrim(rtrim(number_format($item->cantidad, 3, '.', ''), '0'), '.')); ?>

                            </td>
                            <td class="text-end"><?php echo e($item->producto->stock_minimo ?? 0); ?></td>
                            <td>
                                <?php if($item->producto && $item->cantidad <= $item->producto->stock_minimo): ?>
                                    <span class="badge bg-danger"><i class="bi bi-exclamation-triangle me-1"></i>Bajo
                                        mínimo</span>
                                <?php else: ?>
                                    <span class="badge bg-success">OK</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">No hay stock cargado todavía.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($stock->appends(request()->query())->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/stock/index.blade.php ENDPATH**/ ?>