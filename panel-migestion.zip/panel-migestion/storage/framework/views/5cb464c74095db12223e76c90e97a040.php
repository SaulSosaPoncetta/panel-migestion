<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Gestión Comercial')); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <style>
        body {
            min-height: 100vh;
        }

        .sidebar {
            width: 240px;
            min-height: 100vh;
            background: #14532d;
            transition: width .2s ease;
            flex-shrink: 0;
            overflow-x: hidden;
        }

        .sidebar.collapsed {
            width: 68px;
        }

        .sidebar .brand {
            color: #ffffff;
        }

        .sidebar .brand-text {
            white-space: nowrap;
        }

        .sidebar.collapsed .brand-text,
        .sidebar.collapsed .nav-header,
        .sidebar.collapsed .link-label {
            display: none;
        }

        .sidebar .btn-toggle {
            color: #ffffff;
            background: transparent;
            border: none;
        }

        .sidebar .btn-toggle:hover {
            background: rgba(255, 255, 255, .1);
        }

        .sidebar .nav-link {
            color: #ffffff;
            padding: .55rem .85rem;
            display: flex;
            align-items: center;
            white-space: nowrap;
        }

        .sidebar.collapsed .nav-link {
            justify-content: center;
            padding: .55rem 0;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: #ffffff;
            background: #1e6b3a;
            border-radius: .375rem;
        }

        .sidebar .nav-header {
            color: #bfe6cd;
            font-size: .72rem;
            text-transform: uppercase;
            letter-spacing: .05em;
            padding: .75rem 1rem .25rem;
        }

        .main-content {
            flex: 1;
            min-height: 100vh;
            background: #f4f6f8;
            min-width: 0;
        }
    </style>
</head>

<body>
    <div id="app" class="d-flex">
        <nav class="sidebar d-flex flex-column p-2" id="sidebar">
            <div class="d-flex align-items-center justify-content-between px-1 py-2 mb-2">
                <a class="brand d-flex align-items-center text-decoration-none" href="<?php echo e(route('dashboard')); ?>">
                    <i class="bi bi-shop fs-4"></i>
                    <span class="brand-text fs-5 fw-semibold ms-2">Gestión Comercial</span>
                </a>
                <button type="button" class="btn-toggle" id="btn-toggle-sidebar" title="Colapsar/expandir menú">
                    <i class="bi bi-list fs-4"></i>
                </button>
            </div>

            <?php if (! \Illuminate\Support\Facades\Blade::check('role', 'superadmin')): ?>
            <div class="nav-header">Panel</div>
            <a class="nav-link <?php echo e(request()->is('home') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>"
                title="Dashboard">
                <i class="bi bi-speedometer2"></i><span class="link-label ms-2">Dashboard</span>
            </a>

            <div class="nav-header">Catálogo</div>
            <?php if(Route::has('categorias.index')): ?>
                <a class="nav-link <?php echo e(request()->is('categorias*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('categorias.index')); ?>" title="Categorías">
                    <i class="bi bi-diagram-3"></i><span class="link-label ms-2">Categorías</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('marcas.index')): ?>
                <a class="nav-link <?php echo e(request()->is('marcas*') ? 'active' : ''); ?>" href="<?php echo e(route('marcas.index')); ?>"
                    title="Marcas">
                    <i class="bi bi-tags"></i><span class="link-label ms-2">Marcas</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('productos.index')): ?>
                <a class="nav-link <?php echo e(request()->is('productos*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('productos.index')); ?>" title="Productos">
                    <i class="bi bi-box-seam"></i><span class="link-label ms-2">Productos</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('listas-precios.index')): ?>
                <a class="nav-link <?php echo e(request()->is('listas-precios*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('listas-precios.index')); ?>" title="Listas de Precios">
                    <i class="bi bi-cash-coin"></i><span class="link-label ms-2">Listas de Precios</span>
                </a>
            <?php endif; ?>

            <div class="nav-header">Personas</div>
            <?php if(Route::has('personas.index')): ?>
                <a class="nav-link <?php echo e(request()->is('personas*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('personas.index')); ?>" title="Clientes / Proveedores">
                    <i class="bi bi-people"></i><span class="link-label ms-2">Clientes / Proveedores</span>
                </a>
            <?php endif; ?>

            <div class="nav-header">Inventario</div>
            <?php if(Route::has('almacenes.index')): ?>
                <a class="nav-link <?php echo e(request()->is('almacenes*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('almacenes.index')); ?>" title="Almacenes">
                    <i class="bi bi-building"></i><span class="link-label ms-2">Almacenes</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('stock.index')): ?>
                <a class="nav-link <?php echo e(request()->is('stock*') ? 'active' : ''); ?>" href="<?php echo e(route('stock.index')); ?>"
                    title="Stock">
                    <i class="bi bi-boxes"></i><span class="link-label ms-2">Stock</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('transferencias.index')): ?>
                <a class="nav-link <?php echo e(request()->is('transferencias*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('transferencias.index')); ?>" title="Transferencias">
                    <i class="bi bi-arrow-left-right"></i><span class="link-label ms-2">Transferencias</span>
                </a>
            <?php endif; ?>

            <div class="nav-header">Compras y Ventas</div>
            <?php if(Route::has('compras.index')): ?>
                <a class="nav-link <?php echo e(request()->is('compras*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('compras.index')); ?>" title="Compras">
                    <i class="bi bi-cart-plus"></i><span class="link-label ms-2">Compras</span>
                </a>
                <?php if(Route::has('notas-credito-compra.index')): ?>
                    <a class="nav-link <?php echo e(request()->is('notas-credito-compra*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('notas-credito-compra.index')); ?>" title="Notas de Crédito (Compras)">
                        <i class="bi bi-arrow-return-right"></i><span class="link-label ms-2">N. Créd. Compras</span>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Route::has('ventas.index')): ?>
                <a class="nav-link <?php echo e(request()->is('ventas*') ? 'active' : ''); ?>" href="<?php echo e(route('ventas.index')); ?>"
                    title="Ventas">
                    <i class="bi bi-cart-check"></i><span class="link-label ms-2">Ventas</span>
                </a>
                <?php if(Route::has('notas-credito-venta.index')): ?>
                    <a class="nav-link <?php echo e(request()->is('notas-credito-venta*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('notas-credito-venta.index')); ?>" title="Notas de Crédito (Ventas)">
                        <i class="bi bi-arrow-return-left"></i><span class="link-label ms-2">N. Créd. Ventas</span>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Route::has('cajas.index')): ?>
                <a class="nav-link <?php echo e(request()->is('cajas*') ? 'active' : ''); ?>" href="<?php echo e(route('cajas.index')); ?>"
                    title="Cajas">
                    <i class="bi bi-cash-stack"></i><span class="link-label ms-2">Cajas</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('cuentas-por-cobrar.index')): ?>
                <a class="nav-link <?php echo e(request()->is('cuentas-por-cobrar*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('cuentas-por-cobrar.index')); ?>" title="Cuentas por Cobrar">
                    <i class="bi bi-cash"></i><span class="link-label ms-2">Cuentas por Cobrar</span>
                </a>
            <?php endif; ?>
            <?php if(Route::has('cuentas-por-pagar.index')): ?>
                <a class="nav-link <?php echo e(request()->is('cuentas-por-pagar*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('cuentas-por-pagar.index')); ?>" title="Cuentas por Pagar">
                    <i class="bi bi-cash-stack"></i><span class="link-label ms-2">Cuentas por Pagar</span>
                </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gestionar-configuracion')): ?>
                <div class="nav-header">Configuración</div>
                <?php if(Route::has('empresas.index')): ?>
                    <a class="nav-link <?php echo e(request()->is('empresas*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('empresas.index')); ?>" title="Empresas">
                        <i class="bi bi-building-gear"></i><span class="link-label ms-2">Empresas</span>
                    </a>
                <?php endif; ?>
                <?php if(Route::has('sucursales.index')): ?>
                    <a class="nav-link <?php echo e(request()->is('sucursales*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('sucursales.index')); ?>" title="Sucursales">
                        <i class="bi bi-geo-alt"></i><span class="link-label ms-2">Sucursales</span>
                    </a>
                <?php endif; ?>
                <?php if(Route::has('impuestos.index')): ?>
                    <a class="nav-link <?php echo e(request()->is('impuestos*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('impuestos.index')); ?>" title="Impuestos">
                        <i class="bi bi-percent"></i><span class="link-label ms-2">Impuestos</span>
                    </a>
                <?php endif; ?>
                <?php if(Route::has('monedas.index')): ?>
                    <a class="nav-link <?php echo e(request()->is('monedas*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('monedas.index')); ?>" title="Monedas">
                        <i class="bi bi-currency-exchange"></i><span class="link-label ms-2">Monedas</span>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'superadmin')): ?>
                <div class="nav-header">Superadmin</div>
                <a class="nav-link <?php echo e(request()->is('superadmin*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('superadmin.empresas.index')); ?>" title="Empresas del SaaS">
                    <i class="bi bi-buildings"></i><span class="link-label ms-2">Empresas (SaaS)</span>
                </a>
            <?php endif; ?>

            <div class="mt-auto">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" title="Salir"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="bi bi-box-arrow-left"></i><span class="link-label ms-2">Salir
                        (<?php echo e(Auth::user()->name ?? ''); ?>)</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?></form>
            </div>
        </nav>

        <div class="main-content">
            <div class="container-fluid py-4 px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show"><?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (function() {
            const sidebar = document.getElementById('sidebar');
            const btn = document.getElementById('btn-toggle-sidebar');
            const guardado = localStorage.getItem('sidebarCollapsed') === '1';
            if (guardado) sidebar.classList.add('collapsed');

            btn.addEventListener('click', function() {
                sidebar.classList.toggle('collapsed');
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed') ? '1' : '0');
            });
        })();
    </script>
</body>

</html>
<?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercialsaas\resources\views/layouts/app.blade.php ENDPATH**/ ?>