<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse — Gestión Comercial</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <style>
        .bg-primary { background-color: #14532d !important; }
        .btn-primary {
            background-color: #14532d;
            border-color: #14532d;
        }
        .btn-primary:hover,
        .btn-primary:focus,
        .btn-primary:active {
            background-color: #1e6b3a !important;
            border-color: #1e6b3a !important;
        }
        a { color: #14532d; }
        a:hover { color: #1e6b3a; }
        .form-control:focus, .form-select:focus {
            border-color: #14532d;
            box-shadow: 0 0 0 0.25rem rgba(20, 83, 45, 0.15);
        }
    </style>
</head>
<body class="bg-light">

<div class="min-vh-100 d-flex align-items-center justify-content-center py-5">
    <div class="w-100" style="max-width: 520px;">

        <div class="text-center mb-4">
            <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                 style="width:64px;height:64px;">
                <i class="bi bi-shop fs-2"></i>
            </div>
            <h3 class="fw-bold">Gestión Comercial</h3>
            <p class="text-muted">Creá la cuenta de tu empresa</p>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">

                <h5 class="fw-semibold mb-4">Registrar mi empresa</h5>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger py-2 mb-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="small"><i class="bi bi-x-circle me-1"></i><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-2 text-muted small text-uppercase fw-semibold">Datos de tu empresa</div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Razón Social</label>
                        <input type="text" name="razon_social" value="<?php echo e(old('razon_social')); ?>"
                               class="form-control <?php $__errorArgs = ['razon_social'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               required autofocus>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">CUIT / Identificación Fiscal</label>
                        <input type="text" name="identificacion_fiscal" value="<?php echo e(old('identificacion_fiscal')); ?>"
                               class="form-control <?php $__errorArgs = ['identificacion_fiscal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               required>
                    </div>

                    <div class="mb-2 mt-4 text-muted small text-uppercase fw-semibold">Tu cuenta de acceso</div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nombre</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               required autocomplete="name">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               required autocomplete="email">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Contraseña</label>
                        <input type="password" name="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               required autocomplete="new-password">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Confirmar contraseña</label>
                        <input type="password" name="password_confirmation"
                               class="form-control" required autocomplete="new-password">
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-rocket-takeoff me-2"></i>Crear mi empresa y empezar
                        </button>
                    </div>

                </form>

            </div>
        </div>

        <div class="text-center mt-3 small text-muted">
            ¿Ya tenés cuenta?
            <a href="<?php echo e(route('login')); ?>" class="text-decoration-none">Iniciar sesión</a>
        </div>

    </div>
</div>
</body>
</html><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercialsaas\resources\views/auth/register.blade.php ENDPATH**/ ?>