

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-receipt-cutoff me-2"></i>Venta #<?php echo e($venta->id_venta); ?></h3>
    <a href="<?php echo e(route('ventas.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Cliente</div>
                <div class="fw-semibold"><?php echo e($venta->cliente->razon_social_nombre ?? '—'); ?></div>
                <div class="text-muted small mt-2">Vendedor</div>
                <div><?php echo e($venta->vendedor->name ?? '—'); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Fecha</div>
                <div class="fw-semibold"><?php echo e($venta->fecha_venta->format('d/m/Y H:i')); ?></div>
                <div class="text-muted small mt-2">Condición</div>
                <span class="badge bg-<?php echo e($venta->tipo_venta == 'CONTADO' ? 'success' : 'warning'); ?>">
                    <?php echo e($venta->tipo_venta); ?>

                </span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Total</div>
                <div class="fs-4 fw-bold">$<?php echo e(number_format($venta->total_venta, 2)); ?></div>
                <?php if($venta->cuentaPorCobrar): ?>
                <div class="text-muted small mt-2">Saldo Pendiente</div>
                <div class="fw-semibold text-<?php echo e($venta->cuentaPorCobrar->saldo_pendiente > 0 ? 'danger' : 'success'); ?>">
                    $<?php echo e(number_format($venta->cuentaPorCobrar->saldo_pendiente, 2)); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Factura</div>
                <?php if($venta->factura): ?>
                    <div class="fw-semibold"><?php echo e($venta->factura->numero_factura); ?></div>
                    <div class="text-muted small"><?php echo e($venta->factura->tipoComprobante->descripcion ?? ''); ?></div>
                    <span class="badge bg-success mt-1"><?php echo e($venta->factura->estado_fiscal); ?></span>
                <?php else: ?>
                    <div class="text-muted">No se emitió factura</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>SKU</th>
                    <th>Producto</th>
                    <th class="text-end">Cantidad</th>
                    <th class="text-end">Precio Unit.</th>
                    <th class="text-end">Descuento</th>
                    <th class="text-end">Impuesto</th>
                    <th class="text-end">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detalle->producto->sku ?? '—'); ?></td>
                    <td><?php echo e($detalle->producto->nombre ?? '—'); ?></td>
                    <td class="text-end"><?php echo e(rtrim(rtrim(number_format($detalle->cantidad, 3, '.', ''), '0'), '.')); ?></td>
                    <td class="text-end">$<?php echo e(number_format($detalle->precio_unitario, 2)); ?></td>
                    <td class="text-end">$<?php echo e(number_format($detalle->descuento, 2)); ?></td>
                    <td class="text-end">$<?php echo e(number_format($detalle->monto_impuesto, 2)); ?></td>
                    <td class="text-end">$<?php echo e(number_format($detalle->subtotal, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/ventas/show.blade.php ENDPATH**/ ?>