

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-arrow-left-right me-2"></i>Transferencias entre Almacenes</h3>
    <a href="<?php echo e(route('transferencias.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nueva Transferencia
    </a>
</div>

<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('transferencias.index')); ?>" class="d-flex gap-2">
            <select name="id_almacen" class="form-select" style="max-width: 280px;">
                <option value="">Todos los almacenes</option>
                <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($alm->id_almacen); ?>" <?php echo e(request('id_almacen') == $alm->id_almacen ? 'selected' : ''); ?>>
                        <?php echo e($alm->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
            <?php if(request('id_almacen')): ?>
            <a href="<?php echo e(route('transferencias.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Fecha</th>
                    <th>Producto</th>
                    <th>Desde</th>
                    <th>Hasta</th>
                    <th class="text-end">Cantidad</th>
                    <th>Motivo</th>
                    <th>Usuario</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($mov->fecha->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e($mov->producto->nombre ?? '—'); ?></td>
                    <td><span class="badge bg-secondary"><?php echo e($mov->almacenOrigen->nombre ?? '—'); ?></span></td>
                    <td><span class="badge bg-primary"><?php echo e($mov->almacenDestino->nombre ?? '—'); ?></span></td>
                    <td class="text-end"><?php echo e(rtrim(rtrim(number_format($mov->cantidad, 3, '.', ''), '0'), '.')); ?></td>
                    <td><?php echo e($mov->motivo); ?></td>
                    <td><?php echo e($mov->usuario->name ?? '—'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No hay transferencias registradas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($transferencias->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/transferencias/index.blade.php ENDPATH**/ ?>