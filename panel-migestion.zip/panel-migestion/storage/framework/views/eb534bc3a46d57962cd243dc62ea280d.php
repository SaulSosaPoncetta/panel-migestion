

<?php $__env->startSection('content'); ?>
<h3 class="mb-4"><i class="bi bi-arrow-return-left me-2"></i>Nueva Nota de Crédito de Venta</h3>

<div class="card shadow-sm mb-3">
    <div class="card-body">
        <form id="form-nota" action="<?php echo e(route('notas-credito-venta.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label">Venta a la que corresponde la devolución *</label>
                    <select id="selector-venta" name="id_venta" class="form-select <?php $__errorArgs = ['id_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seleccionar...</option>
                        <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($venta->id_venta); ?>" <?php echo e(old('id_venta') == $venta->id_venta ? 'selected' : ''); ?>>
                                Venta #<?php echo e($venta->id_venta); ?> — <?php echo e($venta->cliente->razon_social_nombre ?? 'Sin cliente'); ?> — <?php echo e($venta->fecha_venta->format('d/m/Y')); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Almacén donde repone el stock *</label>
                    <select name="id_almacen" class="form-select <?php $__errorArgs = ['id_almacen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seleccionar...</option>
                        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($alm->id_almacen); ?>" <?php echo e(old('id_almacen') == $alm->id_almacen ? 'selected' : ''); ?>>
                                <?php echo e($alm->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_almacen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label">Motivo *</label>
                    <input type="text" name="motivo" class="form-control <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('motivo')); ?>" placeholder="Producto defectuoso, cliente arrepentido, error de facturación..." required>
                    <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <hr>

            <h5 class="mb-3">Productos a devolver</h5>
            <p class="text-muted small" id="mensaje-sin-venta">Seleccioná una venta arriba para ver sus productos.</p>

            <div class="table-responsive" id="tabla-productos-venta" style="display: none;">
                <table class="table table-sm align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>SKU</th>
                            <th>Producto</th>
                            <th class="text-end">Vendido</th>
                            <th class="text-end">Disponible p/ Devolver</th>
                            <th class="text-end" style="width: 140px;">Cantidad a Devolver</th>
                        </tr>
                    </thead>
                    <tbody id="cuerpo-productos-venta"></tbody>
                </table>
            </div>

            <?php $__errorArgs = ['productos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div id="inputs-ocultos"></div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Emitir Nota de Crédito</button>
                <a href="<?php echo e(route('notas-credito-venta.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    const selectorVenta = document.getElementById('selector-venta');
    const mensajeSinVenta = document.getElementById('mensaje-sin-venta');
    const tablaProductos = document.getElementById('tabla-productos-venta');
    const cuerpoProductos = document.getElementById('cuerpo-productos-venta');
    const inputsOcultos = document.getElementById('inputs-ocultos');

    let lineasDisponibles = [];

    selectorVenta.addEventListener('change', async function () {
        if (!this.value) {
            tablaProductos.style.display = 'none';
            mensajeSinVenta.style.display = 'block';
            cuerpoProductos.innerHTML = '';
            return;
        }

        const url = `<?php echo e(url('notas-credito-venta/datos-venta')); ?>/${this.value}`;
        const resp = await fetch(url);
        lineasDisponibles = await resp.json();

        cuerpoProductos.innerHTML = '';

        lineasDisponibles.forEach((linea, index) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${linea.sku}</td>
                <td>${linea.nombre}</td>
                <td class="text-end">${linea.cantidad_vendida}</td>
                <td class="text-end">${linea.cantidad_disponible}</td>
                <td class="text-end">
                    <input type="number" class="form-control form-control-sm text-end input-cantidad-devolver"
                           data-index="${index}" step="0.001" min="0" max="${linea.cantidad_disponible}" value="0"
                           ${linea.cantidad_disponible <= 0 ? 'disabled' : ''}>
                </td>
            `;
            cuerpoProductos.appendChild(tr);
        });

        tablaProductos.style.display = lineasDisponibles.length ? 'block' : 'none';
        mensajeSinVenta.style.display = lineasDisponibles.length ? 'none' : 'block';
        if (!lineasDisponibles.length) {
            mensajeSinVenta.textContent = 'Esta venta no tiene productos disponibles para devolver.';
        }

        actualizarInputsOcultos();
    });

    cuerpoProductos.addEventListener('input', actualizarInputsOcultos);

    function actualizarInputsOcultos() {
        inputsOcultos.innerHTML = '';
        let contador = 0;

        document.querySelectorAll('.input-cantidad-devolver').forEach((input) => {
            const cantidad = parseFloat(input.value);
            if (!cantidad || cantidad <= 0) return;

            const index = parseInt(input.dataset.index);
            const linea = lineasDisponibles[index];

            ['id_producto', 'precio_unitario'].forEach((campo) => {
                const hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = `productos[${contador}][${campo}]`;
                hidden.value = linea[campo];
                inputsOcultos.appendChild(hidden);
            });

            const hiddenCantidad = document.createElement('input');
            hiddenCantidad.type = 'hidden';
            hiddenCantidad.name = `productos[${contador}][cantidad]`;
            hiddenCantidad.value = cantidad;
            inputsOcultos.appendChild(hiddenCantidad);

            contador++;
        });
    }

    document.getElementById('form-nota').addEventListener('submit', function (e) {
        if (inputsOcultos.children.length === 0) {
            e.preventDefault();
            alert('Ingresá al menos una cantidad a devolver.');
        }
    });
})();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/notas-credito-venta/create.blade.php ENDPATH**/ ?>