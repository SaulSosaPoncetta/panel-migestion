

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-cart-plus me-2"></i>Compras</h3>
    <a href="<?php echo e(route('compras.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nueva Compra
    </a>
</div>

<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('compras.index')); ?>" class="d-flex gap-2">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por N° comprobante o proveedor..."
                   value="<?php echo e(request('buscar')); ?>">
            <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
            <?php if(request('buscar')): ?>
            <a href="<?php echo e(route('compras.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Fecha</th>
                    <th>Comprobante</th>
                    <th>Proveedor</th>
                    <th>Sucursal</th>
                    <th>Condición</th>
                    <th class="text-end">Total</th>
                    <th>Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($compra->fecha_emision->format('d/m/Y')); ?></td>
                    <td><?php echo e($compra->tipo_comprobante); ?> <?php echo e($compra->numero_comprobante); ?></td>
                    <td><?php echo e($compra->proveedor->razon_social_nombre ?? '—'); ?></td>
                    <td><?php echo e($compra->sucursal->nombre ?? '—'); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($compra->condicion_pago == 'CONTADO' ? 'success' : 'warning'); ?>">
                            <?php echo e($compra->condicion_pago); ?>

                        </span>
                    </td>
                    <td class="text-end">$<?php echo e(number_format($compra->total_compra, 2)); ?></td>
                    <td>
                        <?php
                            $colorEstado = match($compra->estado) {
                                'RECIBIDO' => 'success',
                                'PENDIENTE' => 'warning',
                                'ANULADO' => 'danger',
                                default => 'secondary',
                            };
                        ?>
                        <span class="badge bg-<?php echo e($colorEstado); ?>"><?php echo e($compra->estado); ?></span>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('compras.show', $compra)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">No hay compras registradas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($compras->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/compras/index.blade.php ENDPATH**/ ?>