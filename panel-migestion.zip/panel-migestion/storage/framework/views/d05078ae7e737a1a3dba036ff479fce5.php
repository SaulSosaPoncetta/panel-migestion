

<?php $__env->startSection('content'); ?>
<h3 class="mb-4"><i class="bi bi-cart-plus me-2"></i>Nueva Compra</h3>

<div class="card shadow-sm mb-3">
    <div class="card-body">
        <form id="form-compra" action="<?php echo e(route('compras.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3 mb-3">
                <div class="col-md-4">
                    <label class="form-label">Proveedor *</label>
                    <select name="id_proveedor" class="form-select <?php $__errorArgs = ['id_proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seleccionar...</option>
                        <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($prov->id_persona); ?>" <?php echo e(old('id_proveedor') == $prov->id_persona ? 'selected' : ''); ?>>
                                <?php echo e($prov->razon_social_nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Sucursal *</label>
                    <select name="id_sucursal" class="form-select <?php $__errorArgs = ['id_sucursal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seleccionar...</option>
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($suc->id_sucursal); ?>" <?php echo e(old('id_sucursal') == $suc->id_sucursal ? 'selected' : ''); ?>>
                                <?php echo e($suc->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_sucursal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Almacén de destino *</label>
                    <select name="id_almacen" class="form-select <?php $__errorArgs = ['id_almacen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seleccionar...</option>
                        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($alm->id_almacen); ?>" <?php echo e(old('id_almacen') == $alm->id_almacen ? 'selected' : ''); ?>>
                                <?php echo e($alm->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_almacen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Tipo de Comprobante *</label>
                    <input type="text" name="tipo_comprobante" class="form-control <?php $__errorArgs = ['tipo_comprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('tipo_comprobante', 'Factura Proveedor')); ?>" required>
                    <?php $__errorArgs = ['tipo_comprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label">N° Comprobante *</label>
                    <input type="text" name="numero_comprobante" class="form-control <?php $__errorArgs = ['numero_comprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('numero_comprobante')); ?>" required>
                    <?php $__errorArgs = ['numero_comprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Fecha de Emisión *</label>
                    <input type="date" name="fecha_emision" class="form-control <?php $__errorArgs = ['fecha_emision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('fecha_emision', date('Y-m-d'))); ?>" required>
                    <?php $__errorArgs = ['fecha_emision'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Condición de Pago *</label>
                    <select name="condicion_pago" id="condicion_pago" class="form-select <?php $__errorArgs = ['condicion_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="CONTADO" <?php echo e(old('condicion_pago') == 'CONTADO' ? 'selected' : ''); ?>>Contado</option>
                        <option value="CREDITO" <?php echo e(old('condicion_pago') == 'CREDITO' ? 'selected' : ''); ?>>Crédito</option>
                    </select>
                    <?php $__errorArgs = ['condicion_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-3" id="campo-dias-vencimiento" style="display: none;">
                    <label class="form-label">Días para vencimiento</label>
                    <input type="number" name="dias_vencimiento" class="form-control" min="0" value="<?php echo e(old('dias_vencimiento', 30)); ?>">
                </div>
            </div>

            <hr>

            <h5 class="mb-3">Productos</h5>

            <div class="row g-2 mb-2 align-items-end">
                <div class="col-md-5">
                    <label class="form-label small">Producto</label>
                    <select id="selector-producto" class="form-select">
                        <option value="">Seleccionar producto...</option>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($prod->id_producto); ?>"
                                    data-nombre="<?php echo e($prod->nombre); ?>"
                                    data-sku="<?php echo e($prod->sku); ?>"
                                    data-costo="<?php echo e($prod->precio_costo); ?>">
                                <?php echo e($prod->sku); ?> — <?php echo e($prod->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label small">Cantidad</label>
                    <input type="number" id="input-cantidad" class="form-control" step="0.001" min="0.001" value="1">
                </div>
                <div class="col-md-2">
                    <label class="form-label small">Costo Unitario</label>
                    <input type="number" id="input-costo" class="form-control" step="0.01" min="0">
                </div>
                <div class="col-md-3">
                    <button type="button" id="btn-agregar-linea" class="btn btn-outline-primary w-100">
                        <i class="bi bi-plus-lg me-1"></i> Agregar línea
                    </button>
                </div>
            </div>

            <?php $__errorArgs = ['productos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="table-responsive mt-3">
                <table class="table table-sm align-middle" id="tabla-lineas">
                    <thead class="table-light">
                        <tr>
                            <th>SKU</th>
                            <th>Producto</th>
                            <th class="text-end">Cantidad</th>
                            <th class="text-end">Costo Unit.</th>
                            <th class="text-end">Subtotal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="cuerpo-lineas">
                        <tr id="fila-vacia">
                            <td colspan="6" class="text-center text-muted py-3">Todavía no agregaste productos.</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="4" class="text-end">Total</th>
                            <th class="text-end" id="total-compra">$0.00</th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div id="inputs-ocultos"></div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Registrar Compra</button>
                <a href="<?php echo e(route('compras.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    let lineas = [];
    let contador = 0;

    const selectorProducto = document.getElementById('selector-producto');
    const inputCantidad = document.getElementById('input-cantidad');
    const inputCosto = document.getElementById('input-costo');
    const btnAgregar = document.getElementById('btn-agregar-linea');
    const cuerpoLineas = document.getElementById('cuerpo-lineas');
    const filaVacia = document.getElementById('fila-vacia');
    const totalCompraEl = document.getElementById('total-compra');
    const inputsOcultos = document.getElementById('inputs-ocultos');
    const selectCondicion = document.getElementById('condicion_pago');
    const campoDias = document.getElementById('campo-dias-vencimiento');

    selectorProducto.addEventListener('change', function () {
        const opt = this.selectedOptions[0];
        if (opt && opt.dataset.costo) {
            inputCosto.value = opt.dataset.costo;
        }
    });

    function toggleDiasVencimiento() {
        campoDias.style.display = selectCondicion.value === 'CREDITO' ? 'block' : 'none';
    }
    selectCondicion.addEventListener('change', toggleDiasVencimiento);
    toggleDiasVencimiento();

    btnAgregar.addEventListener('click', function () {
        const opt = selectorProducto.selectedOptions[0];
        if (!selectorProducto.value) {
            alert('Seleccioná un producto.');
            return;
        }
        const cantidad = parseFloat(inputCantidad.value);
        const costo = parseFloat(inputCosto.value);
        if (!cantidad || cantidad <= 0) {
            alert('Ingresá una cantidad válida.');
            return;
        }
        if (costo === null || isNaN(costo) || costo < 0) {
            alert('Ingresá un costo válido.');
            return;
        }

        contador++;
        lineas.push({
            id: contador,
            id_producto: selectorProducto.value,
            sku: opt.dataset.sku,
            nombre: opt.dataset.nombre,
            cantidad: cantidad,
            costo_unitario: costo,
        });

        selectorProducto.value = '';
        inputCantidad.value = 1;
        inputCosto.value = '';

        renderizar();
    });

    function eliminarLinea(id) {
        lineas = lineas.filter(l => l.id !== id);
        renderizar();
    }
    window.eliminarLinea = eliminarLinea;

    function renderizar() {
        cuerpoLineas.innerHTML = '';
        inputsOcultos.innerHTML = '';

        if (lineas.length === 0) {
            cuerpoLineas.appendChild(filaVacia);
            totalCompraEl.textContent = '$0.00';
            return;
        }

        let total = 0;

        lineas.forEach((linea, index) => {
            const subtotal = linea.cantidad * linea.costo_unitario;
            total += subtotal;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${linea.sku}</td>
                <td>${linea.nombre}</td>
                <td class="text-end">${linea.cantidad}</td>
                <td class="text-end">$${linea.costo_unitario.toFixed(2)}</td>
                <td class="text-end">$${subtotal.toFixed(2)}</td>
                <td class="text-end">
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="eliminarLinea(${linea.id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            `;
            cuerpoLineas.appendChild(tr);

            ['id_producto', 'cantidad', 'costo_unitario'].forEach(campo => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = `productos[${index}][${campo}]`;
                input.value = linea[campo];
                inputsOcultos.appendChild(input);
            });
        });

        totalCompraEl.textContent = '$' + total.toFixed(2);
    }

    document.getElementById('form-compra').addEventListener('submit', function (e) {
        if (lineas.length === 0) {
            e.preventDefault();
            alert('Agregá al menos un producto a la compra.');
        }
    });
})();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/compras/create.blade.php ENDPATH**/ ?>