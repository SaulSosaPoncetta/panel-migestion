

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-cash-stack me-2"></i>Cajas</h3>
    <a href="<?php echo e(route('cajas.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nueva Caja
    </a>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Nombre</th>
                    <th>Sucursal</th>
                    <th>Estado de Sesión</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($caja->nombre); ?></td>
                    <td><?php echo e($caja->sucursal->nombre ?? '—'); ?></td>
                    <td>
                        <?php if($caja->sesionAbierta): ?>
                            <span class="badge bg-success"><i class="bi bi-unlock me-1"></i>Abierta</span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="bi bi-lock me-1"></i>Cerrada</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <?php if($caja->sesionAbierta): ?>
                            <a href="<?php echo e(route('cajas.sesion', $caja->sesionAbierta)); ?>" class="btn btn-sm btn-primary">
                                <i class="bi bi-cash-coin"></i> Ver Sesión
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('cajas.abrir', $caja)); ?>" class="btn btn-sm btn-outline-success">
                                <i class="bi bi-unlock"></i> Abrir
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('cajas.edit', $caja)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form action="<?php echo e(route('cajas.destroy', $caja)); ?>" method="POST" class="d-inline"
                              onsubmit="return confirm('¿Eliminar esta caja?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">No hay cajas cargadas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($cajas->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/cajas/index.blade.php ENDPATH**/ ?>