

<?php $__env->startSection('content'); ?>
<h3 class="mb-4"><i class="bi bi-lock me-2"></i>Cerrar Caja — <?php echo e($sesion->caja->nombre); ?></h3>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="alert alert-info">
            Según el sistema, el saldo actual de la caja debería ser <strong>$<?php echo e(number_format($saldoSistema, 2)); ?></strong>.
            Contá el efectivo real y cargalo abajo para calcular la diferencia (sobrante o faltante).
        </div>

        <form action="<?php echo e(route('cajas.guardarCierre', $sesion)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Monto Final Real (contado en caja) *</label>
                <input type="number" step="0.01" min="0" name="monto_final_real"
                       class="form-control <?php $__errorArgs = ['monto_final_real'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('monto_final_real', $saldoSistema)); ?>" required autofocus>
                <?php $__errorArgs = ['monto_final_real'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-danger"><i class="bi bi-lock me-1"></i> Confirmar Cierre</button>
                <a href="<?php echo e(route('cajas.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/cajas/cerrar.blade.php ENDPATH**/ ?>