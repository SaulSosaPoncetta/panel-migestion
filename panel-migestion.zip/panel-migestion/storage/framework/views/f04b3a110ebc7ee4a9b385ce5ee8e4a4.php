

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0"><i class="bi bi-arrow-return-right me-2"></i>Notas de Crédito de Compra</h3>
    <a href="<?php echo e(route('notas-credito-compra.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nueva Nota de Crédito
    </a>
</div>

<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('notas-credito-compra.index')); ?>" class="d-flex gap-2">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por número de nota..."
                   value="<?php echo e(request('buscar')); ?>">
            <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
            <?php if(request('buscar')): ?>
            <a href="<?php echo e(route('notas-credito-compra.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead class="table-light">
                <tr>
                    <th>Número</th>
                    <th>Fecha</th>
                    <th>Compra Original</th>
                    <th>Proveedor</th>
                    <th class="text-end">Total</th>
                    <th>Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($nota->numero_nota); ?></td>
                    <td><?php echo e($nota->fecha->format('d/m/Y')); ?></td>
                    <td><a href="<?php echo e(route('compras.show', $nota->id_compra)); ?>">Compra #<?php echo e($nota->id_compra); ?></a></td>
                    <td><?php echo e($nota->compra->proveedor->razon_social_nombre ?? '—'); ?></td>
                    <td class="text-end">$<?php echo e(number_format($nota->total, 2)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($nota->estado == 'EMITIDA' ? 'success' : 'danger'); ?>"><?php echo e($nota->estado); ?></span>
                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('notas-credito-compra.show', $nota)); ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No hay notas de crédito registradas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($notas->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/notas-credito-compra/index.blade.php ENDPATH**/ ?>