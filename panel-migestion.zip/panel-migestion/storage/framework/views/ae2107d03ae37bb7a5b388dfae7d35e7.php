<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0"><i class="bi bi-box-seam me-2"></i>Productos</h3>
        <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Nuevo Producto
        </a>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body py-2">
            <form method="GET" action="<?php echo e(route('productos.index')); ?>" class="d-flex gap-2">
                <input type="text" name="buscar" class="form-control"
                    placeholder="Buscar por nombre, SKU o código de barras..." value="<?php echo e(request('buscar')); ?>">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if(request('buscar')): ?>
                    <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-outline-secondary"><i
                            class="bi bi-x-lg"></i></a>
                <?php endif; ?>
                <a href="<?php echo e(route('productos.exportar', request()->query())); ?>" class="btn btn-outline-success ms-auto">
                    <i class="bi bi-file-earmark-excel me-1"></i> Exportar a Excel
                </a>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>SKU</th>
                        <th>Nombre</th>
                        <th>Categoría</th>
                        <th>Marca</th>
                        <th>Impuesto</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-costos')): ?>
                            <th class="text-end">Costo</th>
                        <?php endif; ?>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($producto->sku); ?></td>
                            <td><?php echo e($producto->nombre); ?></td>
                            <td><?php echo e($producto->categoria->nombre ?? '—'); ?></td>
                            <td><?php echo e($producto->marca->nombre ?? '—'); ?></td>
                            <td><?php echo e($producto->impuesto->nombre ?? '—'); ?></td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-costos')): ?>
                                <td class="text-end">$<?php echo e(number_format($producto->precio_costo, 2)); ?></td>
                            <?php endif; ?>
                            <td>
                                <?php if($producto->estado): ?>
                                    <span class="badge bg-success">Activo</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('productos.edit', $producto)); ?>"
                                    class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-registros')): ?>
                                    <form action="<?php echo e(route('productos.destroy', $producto)); ?>" method="POST" class="d-inline"
                                        onsubmit="return confirm('¿Eliminar este producto?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">No hay productos cargados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($productos->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/productos/index.blade.php ENDPATH**/ ?>