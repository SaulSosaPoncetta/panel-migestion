

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0"><i class="bi bi-cart-check me-2"></i>Ventas</h3>
        <a href="<?php echo e(route('ventas.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Nueva Venta
        </a>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body py-2">
            <form method="GET" action="<?php echo e(route('ventas.index')); ?>" class="d-flex gap-2">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar por cliente..."
                    value="<?php echo e(request('buscar')); ?>">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if(request('buscar')): ?>
                    <a href="<?php echo e(route('ventas.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
                <?php endif; ?>
                <a href="<?php echo e(route('ventas.exportar', request()->query())); ?>" class="btn btn-outline-success ms-auto">
                    <i class="bi bi-file-earmark-excel me-1"></i> Exportar a Excel
                </a>
            </form>
        </div>
    </div>
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Vendedor</th>
                        <th>Condición</th>
                        <th class="text-end">Total</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($venta->fecha_venta->format('d/m/Y H:i')); ?></td>
                            <td><?php echo e($venta->cliente->razon_social_nombre ?? '—'); ?></td>
                            <td><?php echo e($venta->vendedor->name ?? '—'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($venta->tipo_venta == 'CONTADO' ? 'success' : 'warning'); ?>">
                                    <?php echo e($venta->tipo_venta); ?>

                                </span>
                            </td>
                            <td class="text-end">$<?php echo e(number_format($venta->total_venta, 2)); ?></td>
                            <td>
                                <?php
                                    $colorEstado = match ($venta->estado) {
                                        'COMPLETADA' => 'success',
                                        'PRESUPUESTO' => 'secondary',
                                        'ANULADA' => 'danger',
                                        default => 'secondary',
                                    };
                                ?>
                                <span class="badge bg-<?php echo e($colorEstado); ?>"><?php echo e($venta->estado); ?></span>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('ventas.show', $venta)); ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No hay ventas registradas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($ventas->appends(request()->query())->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestioncomercial\resources\views/ventas/index.blade.php ENDPATH**/ ?>